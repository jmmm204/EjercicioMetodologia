﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RegistroDeEstudiantes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            //Asignar eventos Keypress a los TextBox
            txtNombre.KeyPress += new KeyPressEventHandler(SoloLetras_KeyPress);
            txtApellido.KeyPress += new KeyPressEventHandler(SoloLetras_KeyPress);
            txtNumero.KeyPress += new KeyPressEventHandler(SoloNumeros_KeyPress);
            txtPromedio.KeyPress += new KeyPressEventHandler(SoloNumeros_KeyPress);
            txtMaterias.KeyPress += new KeyPressEventHandler(SoloNumeros_KeyPress);

            ConfigurarDataGridView();
            CargarOpcionesCarrera();
        }

        private void ConfigurarDataGridView()
        {
            // Configuración básica para el DataGridView
            dataGridViewEstudiantes.Columns.Add("Nombre", "Nombre");
            dataGridViewEstudiantes.Columns.Add("Apellido", "Apellido");
            dataGridViewEstudiantes.Columns.Add("NumeroEstudiante", "Número de Estudiante");
            dataGridViewEstudiantes.Columns.Add("Carrera", "Carrera");
            dataGridViewEstudiantes.Columns.Add("Promedio", "Promedio General");
            dataGridViewEstudiantes.Columns.Add("MateriasAprobadas", "Materias Aprobadas");

            // Añadir el ContextMenuStrip al DataGridView
            ContextMenuStrip contextMenu = new ContextMenuStrip();
            ToolStripMenuItem editarMenuItem = new ToolStripMenuItem("Editar", null, EditarEstudiante);
            ToolStripMenuItem eliminarMenuItem = new ToolStripMenuItem("Eliminar", null, EliminarEstudiante);
            contextMenu.Items.AddRange(new ToolStripItem[] { editarMenuItem, eliminarMenuItem });
            dataGridViewEstudiantes.ContextMenuStrip = contextMenu;
        }

        private void CargarOpcionesCarrera()
        {
            cmbCarrera.Items.AddRange(new string[] {
                "Ingeniería", "Medicina", "Derecho", "Administración"
            });
            cmbCarrera.SelectedIndex = 0;
        }

        // Funcion que solo permite numeros
        private void SoloNumeros_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Verificar si el caracter es un digito o una tecla de control
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true; // Rechaza el caracter si no es un numero o control
            }
        }

        // Funcion que solo permite letras
        private void SoloLetras_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Verificar si el caracter es una letra o una tecla de control
            if (!char.IsLetter(e.KeyChar) && !char.IsControl(e.KeyChar) && e.KeyChar != ' ')
            {
                e.Handled = true; // Rechaza el caracter si no es letra, espacio o control
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtNombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtApellido_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtApellido_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void nuevoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LimpiarCampos();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            // Agregar datos del estudiante al DataGridView
            dataGridViewEstudiantes.Rows.Add(
                txtNombre.Text,
                txtApellido.Text,
                txtNumero.Text,
                cmbCarrera.SelectedItem.ToString(),
                txtPromedio.Text,
                txtMaterias.Text
            );
            LimpiarCampos();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            // Eliminar el estudiante seleccionado del DataGridView
            if (dataGridViewEstudiantes.SelectedRows.Count > 0)
            {
                dataGridViewEstudiantes.Rows.RemoveAt(dataGridViewEstudiantes.SelectedRows[0].Index);
            }
            else
            {
                MessageBox.Show("Seleccione un estudiante para eliminar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            // Refrescar la lista de estudiantes
            dataGridViewEstudiantes.Refresh();
        }

        private void EditarEstudiante(object sender, EventArgs e)
        {
            // Implementación para editar un estudiante seleccionado en el DataGridView
            if (dataGridViewEstudiantes.SelectedRows.Count > 0)
            {
                DataGridViewRow fila = dataGridViewEstudiantes.SelectedRows[0];
                txtNombre.Text = fila.Cells["Nombre"].Value.ToString();
                txtApellido.Text = fila.Cells["Apellido"].Value.ToString();
                txtNumero.Text = fila.Cells["NumeroEstudiante"].Value.ToString();
                cmbCarrera.SelectedItem = fila.Cells["Carrera"].Value.ToString();
                txtPromedio.Text = fila.Cells["Promedio"].Value.ToString();
                txtMaterias.Text = fila.Cells["MateriasAprobadas"].Value.ToString();
                dataGridViewEstudiantes.Rows.Remove(fila);
            }
            else
            {
                MessageBox.Show("Seleccione un estudiante para editar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void EliminarEstudiante(object sender, EventArgs e)
        {
            // Eliminar el estudiante seleccionado usando el ContextMenuStrip
            btnEliminar_Click(sender, e);
        }

        private void LimpiarCampos()
        {
            // Limpiar los campos del formulario después de guardar
            txtNombre.Clear();
            txtApellido.Clear();
            txtNumero.Clear();
            cmbCarrera.SelectedIndex = 0;
            txtPromedio.Clear();
            txtMaterias.Clear();
        }
    }
}